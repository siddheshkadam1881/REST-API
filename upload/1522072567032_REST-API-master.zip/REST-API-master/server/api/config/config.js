module.exports = {
  'secret': 'supersecret'
};
