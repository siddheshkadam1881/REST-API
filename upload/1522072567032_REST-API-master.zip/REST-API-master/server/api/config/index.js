module.exports = {
  mongoose:require("./initDb")(),
  config : require("./config")
};
